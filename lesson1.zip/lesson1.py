print ((9 * 5) ** 0,5 / 1) #1st program
print (9.99 > 9,98 and 1000 != 1000.1) #2st program
print (2 * 2 + 2 == (2 + 2) * 2) #3st program
print (int (4) + (123.456 * 10) % 5 // 10) #4st program