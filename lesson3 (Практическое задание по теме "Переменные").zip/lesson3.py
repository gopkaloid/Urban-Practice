The_number_of_completed_HA = 12
Number_of_hours_spent = 1.5
Course_name = 'Python'
Time_for_one_task = int (12 / 1.5)
print ('Cours:', Course_name, ',', 'total tasks:', The_number_of_completed_HA, ',', 'hours spent:', Number_of_hours_spent, ',', 'average execution time', Time_for_one_task, 'hours')
